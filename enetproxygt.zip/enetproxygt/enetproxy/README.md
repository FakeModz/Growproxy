# Growtopia enet proxy edited by SrMotion#0001
Growtopia enet proxy that allows modification and viewing of packets, and creation of new ones.
## How to use
* Does not need separate http server

* Build with Release x64

* Start proxy -> auto patch hosts -> Works as supposed

## Features
* Print all variantlists and function calls
* Print all text packets
* Supports modifying, ignoring, and making new packets
* /legal command to clear malpractice without owning legal briefs
* More commands which you can find in the changelog
* Has a PoC /name name command to call OnNameChanged function for local client.
* Has a PoC OnSpawn modifier which appends netid to each players' name, and gives you unlim zoom
* Can both intercept outgoing and incoming packets
* Integrated http server
* Ignore tracking packets and crash log requests
* Ignore autoban packets (NOTE: you can still get autobanned if the check is serversided)
* Works with subserver switching
* Wrench Pull/ban/kick
* Auto Casino Tax Calculator
* Bypass Safe Vault
* Fast Drop/Trash
* Dice Speed
* Exit world when mod joins
* Visual Spin
* World Lock Troll
* Pull/kick/ban all
* and more features
## Credits
* ama6nen
* wry // thanks for helps
* wh1ter0se //thanks for helps
